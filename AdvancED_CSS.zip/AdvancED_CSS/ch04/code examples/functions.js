function printThisPage()
	{

	if (window.print) {
		window.print();
		}
	else
		alert("Please choose print from the File menu.");
	}
}